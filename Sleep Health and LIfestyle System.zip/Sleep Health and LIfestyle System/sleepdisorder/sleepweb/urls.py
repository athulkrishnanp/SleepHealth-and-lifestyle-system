from django.urls import path
from . import views

urlpatterns = [
path('', views.home, name='home'),
path('login',views.login,name='login'),
path('home',views.home,name='home'),
path('register',views.register,name='register'),
path('loginhandler',views.loginhandler,name='loginhandler'),
path('userhome',views.userhome,name='userhome'),
path('registerhandler',views.registerhandler,name='registerhandler'),
path('prediction',views.prediction,name='prediction'),
path('predictionhandler',views.predictionhandler,name='predictionhandler'),
path('healthy',views.healthy,name='healthy'),
path('disorder',views.disorder,name='disorder'),
path('analysis',views.analysis,name='analysis'),
path('adminlogin', views.adminlogin, name='adminlogin'),
path('admincheck', views.admincheck, name='admincheck'),
path('adminpanel', views.adminpanel, name='adminpanel'),
path('adminlogout', views.adminlogout, name='adminlogout'),
]