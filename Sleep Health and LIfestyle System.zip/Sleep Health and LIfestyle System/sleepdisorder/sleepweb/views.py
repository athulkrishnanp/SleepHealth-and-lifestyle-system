from django.shortcuts import render

def home(request):
    return render(request, 'sleepweb/home.html')

def login(request):
    return render(request, 'sleepweb/login.html')

def register(request):
    return render(request, 'sleepweb/register.html')

def userhome(request):
    name = request.session.get("Name", "")
    return render(request, 'sleepweb/userhome.html', {"Name": name})

from django.db import models

class UserData(models.Model):
    Name = models.CharField(max_length=100)
    Gender = models.CharField(max_length=20)
    Email = models.CharField(max_length=100)
    Phone = models.CharField(max_length=20)
    Username = models.CharField(max_length=50, unique=True)
    Password = models.CharField(max_length=100)

    class Meta:
        db_table = 'userdata'   # 👈 old MySQL table name

    def __str__(self):
        return self.Username



class LoginHistory(models.Model):
    username = models.CharField(max_length=50)
    login_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'login_history'   # 👈 old MySQL table name

def loginhandler(request):
    import sqlite3

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        conn = sqlite3.connect("sleepdb.sqlite")
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        # Login check
        q = "SELECT * FROM userdata WHERE Username=? AND Password=?"
        cursor.execute(q, (username, password))
        user = cursor.fetchone()

        if user:
            request.session["user"] = username

            # Insert login history
            cursor.execute(
                "INSERT INTO login_history(username, login_time) VALUES(?, datetime('now'))",
                (username,)
            )
            conn.commit()
            conn.close()

            return render(request, "sleepweb/userhome.html", {"Name": user["Name"]})
        else:
            conn.close()
            return render(request, "sleepweb/login.html", {"msg": "Invalid Credentials"})

    return render(request, "sleepweb/login.html")


def registerhandler(request):
    import sqlite3

    Name = request.POST.get("fullname")
    Gender = request.POST.get("gen")
    Email = request.POST.get("mail")
    Phone = request.POST.get("phonen")
    Username = request.POST.get("username")
    Password = request.POST.get("password")

    conn = sqlite3.connect("sleepdb.sqlite")
    cursor = conn.cursor()

    q = """INSERT INTO userdata 
           (Name, Gender, Email, Phone, Username, Password) 
           VALUES (?, ?, ?, ?, ?, ?)"""

    cursor.execute(q, (Name, Gender, Email, Phone, Username, Password))
    conn.commit()
    conn.close()

    request.session["Name"] = Name
    return render(request, 'sleepweb/register.html', {"msg": "Registration Succesful"})


def prediction(request):
    return render(request, 'sleepweb/prediction.html')

def healthy(request):
    return render(request,'sleepweb/healthy.html')

def disorder(request):
    return render(request,'sleepweb/disorder.html')

import os
import pickle
import pandas as pd
import mysql.connector
from django.conf import settings
from django.shortcuts import render


def predictionhandler(request):
    if request.method == 'POST':

        # ------------------------------
        # 1️⃣ Load Model and Preprocessor
        # ------------------------------
        model_path = os.path.join(settings.BASE_DIR, 'sleepweb', 'ml_model', 'sleep_rf_model.pkl')
        preprocessor_path = os.path.join(settings.BASE_DIR, 'sleepweb', 'ml_model', 'sleep_preprocessor.pkl')

        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        with open(preprocessor_path, 'rb') as f:
            preprocessor = pickle.load(f)

        # ------------------------------
        # 2️⃣ Safe float conversion
        # ------------------------------
        def get_float(key, default=0):
            try:
                return float(request.POST.get(key) or default)
            except ValueError:
                return default

        # ------------------------------
        # 3️⃣ Collect form data
        # ------------------------------
        gender = request.POST.get('gender', 'Male').strip().title()
        age = get_float('age')
        occupation = request.POST.get('occ', '').strip().title()
        sleep_duration = get_float('sd')
        quality_sleep = get_float('sq')
        physical_activity = get_float('pa')
        stress_level = get_float('sl')
        bmi_category = request.POST.get('bmi', 'Normal').strip().title()
        heart_rate = get_float('hr')
        daily_steps = get_float('ds')
        systolic = get_float('sys')
        diastolic = get_float('dia')

        # ------------------------------
        # 4️⃣ Create DataFrame
        # ------------------------------
        input_df = pd.DataFrame([{
            'Gender': gender,
            'Age': age,
            'Occupation': occupation,
            'Sleep Duration': sleep_duration,
            'Quality of Sleep': quality_sleep,
            'Physical Activity Level': physical_activity,
            'Stress Level': stress_level,
            'BMI Category': bmi_category,
            'Heart Rate': heart_rate,
            'Daily Steps': daily_steps,
            'Systolic': systolic,
            'Diastolic': diastolic
        }])

        # ------------------------------
        # 5️⃣ Map categorical values
        # ------------------------------
        occupation_map = {
            'Software engineer': 'Software Engineer', 'Manager': 'Manager',
            'Doctor': 'Doctor', 'Teacher': 'Teacher', 'Nurse': 'Nurse',
            'Lawyer': 'Lawyer', 'Salesperson': 'Salesperson',
            'Sales representative': 'Sales Representative', 'Scientist': 'Scientist',
            'Engineer': 'Engineer', 'Accountant': 'Accountant'
        }
        input_df['Occupation'] = input_df['Occupation'].map(occupation_map).fillna(input_df['Occupation'])

        bmi_map = {'Normal': 'Normal', 'Overweight': 'Overweight', 'Obese': 'Obese', 'Normal Weight': 'Normal'}
        input_df['BMI Category'] = input_df['BMI Category'].map(bmi_map).fillna('Normal')

        gender_map = {'Male': 'Male', 'Female': 'Female'}
        input_df['Gender'] = input_df['Gender'].map(gender_map).fillna('Male')

        # ------------------------------
        # 6️⃣ Preprocess & Predict
        # ------------------------------
        processed_input = preprocessor.transform(input_df)
        prediction = model.predict(processed_input)[0]

        mapping = {0: "No Disorder", 1: "Insomnia", 2: "Sleep Apnea"}

        try:
            pred_int = int(prediction)
            predicted_label = mapping.get(pred_int, str(prediction))
        except:
            predicted_label = str(prediction)

        predicted_str = predicted_label.lower()

        # ------------------------------
        # 7️⃣ Save prediction history
        # ------------------------------
        import sqlite3
        import os

        username = request.session.get("user", "Guest")

        DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "sleepdb.sqlite")
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        q = """INSERT INTO prediction_history
        (username, gender, age, occupation, sleep_duration, quality_sleep,
        physical_activity, stress_level, bmi_category, heart_rate, daily_steps,
        systolic, diastolic, prediction, predicted_on)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))"""

        cursor.execute(q, (
            username, gender, age, occupation, sleep_duration, quality_sleep,
            physical_activity, stress_level, bmi_category, heart_rate,
            daily_steps, systolic, diastolic, predicted_label
        ))

        conn.commit()
        conn.close()

        # ------------------------------
        # 8️⃣ Render Result Page
        # ------------------------------
        if predicted_str == "no disorder":
            return render(request, 'sleepweb/healthy.html', {'result': predicted_label})

        elif predicted_str in ["insomnia", "sleep apnea"]:
            return render(request, 'sleepweb/disorder.html', {'result': predicted_label})

        else:
            return render(request, 'sleepweb/prediction.html', {'result': predicted_label})

    # GET Request → Show form
    return render(request, 'sleepweb/prediction.html')


import os
import io
import base64
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from django.conf import settings
from django.shortcuts import render

def analysis(request):
    # ------------------------------
    # 1️⃣ Load CSV
    # ------------------------------
    filepath = os.path.join(settings.BASE_DIR,'sleepweb','ml_model','Sleep_health_and_lifestyle_dataset.csv')  # replace with your CSV
    df = pd.read_csv(filepath)

    # ------------------------------
    # 2️⃣ Normalize 'Sleep Disorder' column
    # ------------------------------
    df['Sleep Disorder'] = df['Sleep Disorder'].replace({
        0: 'No Disorder',
        '0': 'No Disorder',
        None: 'No Disorder',
        '': 'No Disorder'
    })

    # ------------------------------
    # 3️⃣ Prepare charts
    # ------------------------------

    charts = {}

    # 3.1 Pie chart: Sleep Disorder distribution
    plt.figure(figsize=(6,6))
    labels = df['Sleep Disorder'].value_counts().index.tolist()
    values = df['Sleep Disorder'].value_counts().values
    colors = ['#16a34a', '#facc15', '#ef4444'][:len(labels)]
    plt.pie(values, labels=labels, autopct='%1.1f%%', startangle=90, colors=colors, shadow=True)
    plt.title('Sleep Disorder Distribution')
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    plt.close()
    buffer.seek(0)
    charts['graph1'] = base64.b64encode(buffer.getvalue()).decode('utf-8')

    # 3.2 Histogram: Sleep Duration
    plt.figure(figsize=(10,5))
    sns.histplot(df['Sleep Duration'], kde=True, color='#2563eb')
    plt.title('Sleep Duration Distribution')
    plt.xlabel('Hours')
    plt.ylabel('Count')
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    plt.close()
    buffer.seek(0)
    charts['graph2'] = base64.b64encode(buffer.getvalue()).decode('utf-8')

    # 3.3 Bar chart: Average Quality of Sleep by Sleep Disorder
    plt.figure(figsize=(10,5))
    sns.barplot(x='Sleep Disorder', y='Quality of Sleep', data=df, ci=None, palette='viridis')
    plt.title('Average Quality of Sleep by Disorder')
    plt.ylabel('Quality of Sleep')
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    plt.close()
    buffer.seek(0)
    charts['graph3'] = base64.b64encode(buffer.getvalue()).decode('utf-8')

    # 3.4 Scatter plot: Sleep Duration vs Physical Activity colored by Sleep Disorder
    plt.figure(figsize=(10,5))
    sns.scatterplot(x='Physical Activity Level', y='Sleep Duration', hue='Sleep Disorder', data=df, palette='Set2')
    plt.title('Sleep Duration vs Physical Activity')
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    plt.close()
    buffer.seek(0)
    charts['graph4'] = base64.b64encode(buffer.getvalue()).decode('utf-8')

    # 3.5 Box plot: Sleep Duration by BMI Category
    avg_quality = df.groupby('Occupation')['Quality of Sleep'].mean().reset_index()
    plt.figure(figsize=(12,6))
    sns.heatmap(avg_quality.set_index('Occupation').T, annot=True, cmap='YlGnBu', cbar=True)
    plt.title('Average Quality of Sleep by Occupation (Heatmap)')
    plt.xlabel('Occupation')
    plt.ylabel('')
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    plt.close()
    buffer.seek(0)
    charts['graph5'] = base64.b64encode(buffer.getvalue()).decode('utf-8')


    # ------------------------------
    # 4️⃣ Render template
    # ------------------------------
    return render(request, 'sleepweb/analysis.html', charts)

from django.shortcuts import render, redirect
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "sleepdb.sqlite")


# -----------------------
# Admin login page
# -----------------------
def adminlogin(request):
    return render(request, "sleepweb/adminlogin.html")


# -----------------------
# Admin authentication
# -----------------------
def admincheck(request):
    adminuser = request.POST.get("username")
    adminpass = request.POST.get("password")

    if adminuser == "admin" and adminpass == "admin123":
        request.session["admin"] = adminuser
        return redirect("adminpanel")  # URL name
    else:
        return render(request, "sleepweb/adminlogin.html", {"msg": "Invalid login"})


# -----------------------
# Admin panel
# -----------------------
def adminpanel(request):
    print("🟦 ADMIN PANEL LOADED")

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    # ----- LOGIN HISTORY -----
    cursor.execute("SELECT * FROM login_history ORDER BY login_time DESC")
    logins = cursor.fetchall()

    # ----- PREDICTION HISTORY -----
    cursor.execute("SELECT * FROM prediction_history ORDER BY predicted_on DESC")
    predictions = cursor.fetchall()

    conn.close()

    return render(request, "sleepweb/adminpanel.html", {
        "logins": logins,
        "predictions": predictions
    })


# -----------------------
# Admin logout
# -----------------------
def adminlogout(request):
    request.session.flush()
    return render(request,"sleepweb/adminlogin.html")
