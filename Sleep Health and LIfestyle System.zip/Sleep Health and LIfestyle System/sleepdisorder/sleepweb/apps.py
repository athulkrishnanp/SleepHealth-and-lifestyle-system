from django.apps import AppConfig


class SleepwebConfig(AppConfig):
    name = 'sleepweb'
